import { Component, OnInit , Input, Output, EventEmitter,ViewChild, AfterViewInit, ElementRef,OnDestroy} from '@angular/core';

import { FormGroup, FormControl } from '@angular/forms';
import {TaskManager} from '../TaskManager';

import {TaskServiceService} from '../task-service.service';

import {TaskManagerMaster,JsonResponse} from '../TaskManager';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css']
})
export class EditTaskComponent implements OnInit {
  parentid:string;
	taskid : string;
  task : string ;
  parenttask : string;
	startdate : string ;
	 enddate : string ;
	 priority : string ;
	 parentTask : string ;
	 taskstatus: string ;
   responsemsg : string;
  constructor(private route: ActivatedRoute,
    private router: Router,
    public taskService : TaskServiceService) { 
   
  }
  
  taskManager : TaskManager;
  taskEditForm = new FormGroup({
    task : new FormControl,
    parenttask : new FormControl,
    priority : new FormControl,
    
    startdate : new FormControl,
    enddate: new FormControl

  });
  ngOnInit() {
    
    this.parentid = this.route.snapshot.paramMap.get('parentid');
    
    this.taskid = this.route.snapshot.paramMap.get('taskid');
    
    this.task = this.route.snapshot.paramMap.get('task');
    this.parenttask = this.route.snapshot.paramMap.get('parentTask');
    this.startdate = this.route.snapshot.paramMap.get('startdate');
    this.enddate = this.route.snapshot.paramMap.get('enddate');
    this.priority = this.route.snapshot.paramMap.get('priority');
    
    this.taskEditForm = new FormGroup({
      parentid : new FormControl(this.parentid),
      taskid : new FormControl(this.taskid),
      task : new FormControl(this.task),
      parenttask : new FormControl(this.parenttask),
      
      startdate : new FormControl(this.startdate),

      enddate : new FormControl(this.enddate),
      priority : new FormControl(this.priority),
    });
      
    

  }
 

  
 public submitForm(){
  this.taskService.updateTask(this.taskEditForm.value).subscribe(data=>{
    console.log(data);
    this.responsemsg =data.taskstatus;
  });
 }
 
   onBack(): void {
    this.router.navigate(['/viewTask']);
  }


}
