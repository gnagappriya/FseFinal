import { Component, OnInit, ViewChild, AfterViewInit, ElementRef,OnDestroy } from '@angular/core';
import {TaskServiceService} from '../task-service.service';
import { FormGroup, FormControl } from '@angular/forms';
import {TaskManagerMaster,JsonResponse} from '../TaskManager';


@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.css']
})
export class ViewTaskComponent implements OnInit,AfterViewInit {

  //@ViewChild('startPopup') startPopup: ElementRef;

  ngAfterViewInit(){
    // setTimeout(()=>{
    //   this.startPopup.nativeElement.click();
    // },200);
  }
  filteredTasks: TaskManagerMaster[] = [];
  tasklist: TaskManagerMaster[] = [];
  _listFilter = '';
  get listFilter(): string {
    return this._listFilter;
  }
  set listFilter(value: string) {
    this._listFilter = value;
   // this.filteredTasks = this.filterTask(value);
  }
  

  // filterTask(value: string): TaskManagerMaster[] {
  //   return this.tasklist.filter(
  //     task1=>task1.task.toLocaleLowerCase.indexOf()
  //   );
  //   //return this.tasklist.filter(
  //     //task1 => task1.task.toLocaleLowerCase.indexOf(filterBy.toLocaleLowerCase())!==-1
  //   //);
  // // return this.taskmanagerlist.filter((product: TaskManagerMaster) =>
  // // tasks.task.toLocaleLowerCase().indexOf(filterBy) !== -1);
  //  }

  taskViewForm = new FormGroup({
    task : new FormControl(''),
    parenttask : new FormControl(''),
    priorityfrom : new FormControl(''),
    priorityto : new FormControl(''),
    startdate : new FormControl(''),
    enddate: new FormControl('')

  });
public openModal1(content){

}
  
  taskmanagerlist : TaskManagerMaster[]=[] ;
  showDisableButton : boolean = true;

  constructor(public taskService : TaskServiceService) { }

  ngOnInit() {
    this.getTaskManagerMaster();
   // this.tasklist = this.getTasks();;
  }
  
// public getTasks(): TaskManagerMaster[]{
//  return  this.taskService.getTaskManagerMaster().subscribe(data=>{
//     console.log("test");
//     if(data.taskmanagerlist !=null){
//       this.taskmanagerlist = data.taskmanagerlist;
//       console.log(this.taskmanagerlist);
//     }
//   });
// }
  // open(content) {, private modalService: NgbModal
  //   this.modalService.open(content);
  // }
 sessionStorage: Storage;
  public  getTaskManagerMaster(){
    console.log("In ViewTaskComponent - getTaskManagerMaster");
   
    this.taskService.getTaskManagerMaster().subscribe(data=>{
      console.log("test");
      if(data.taskmanagerlist !=null){
        this.taskmanagerlist = data.taskmanagerlist;
        //JSON.parse(sessionStorage.setItem(this.taskmanagerlist));
    
        for(let tmm of this.taskmanagerlist){
          //alert(tmm.startdate)
        }
        console.log(this.taskmanagerlist);
        
      }
    });
   
  }

 public endTask( t){
    console.log("In ViewTaskComponent - endTask");
   
    this.taskService.endTask(t);

    this.taskService.endTask(t).subscribe(data=>{
      console.log(data);
      if(data.taskmanagerlist !=null){
        this.taskmanagerlist = data.taskmanagerlist;
        console.log(this.taskmanagerlist);
        
      }
      this.getTaskManagerMaster();
    });
    
  }

  checkBusttonStatus(taskStatus):boolean{
  if(taskStatus=="SUSPENDED"){
    return true;
  }
  else{
    return false;
  }
}
}
