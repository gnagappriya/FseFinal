import { Component, OnInit } from '@angular/core';

import { FormGroup, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import {TaskManager,User, AddUser} from '../TaskManager';
import {TaskServiceService} from '../task-service.service';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';

import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css'],
  providers: [DatePipe]
})
export class AddProjectComponent implements OnInit {
  myDate = new Date();
  nextDayDate = new Date();
 
  

  users : AddUser[]=[] ;
  projects: any;
  selecteduser: string;
  constructor(private route: ActivatedRoute,
    private router: Router,
    public taskService : TaskServiceService,private datePipe: DatePipe) {
     }

  ngOnInit() {
    
    this.nextDayDate.setDate(this.myDate.getDate()+1);
    this.addProjectForm.get('sd').disable();
    this.addProjectForm.get('ed').disable();
    let date = JSON.stringify(this.myDate)
    let nextday = JSON.stringify(this.nextDayDate)
    date = date.slice(1,11)
    nextday = nextday.slice(1,11)
    this.addProjectForm.get('sd').setValue(date);
    this.addProjectForm.get('ed').setValue(nextday);
    this.addProjectForm.get('priority').setValue(0);
    this.getAllProjects()
  }

  addProjectForm = new FormGroup({
    project: new FormControl(''),
    checkDate: new FormControl(''),
    startdate: new FormControl(''),
    priority: new FormControl(''),
    enddate: new FormControl(''),
    user: new FormControl(''),
    manager: new FormControl(''),
    sd: new FormControl(''),
    ed: new FormControl(),
    completed : new FormControl(''),
  });
 projectid:string="";
 sdate:string="";
 edate:string="";
 prio:number;
 manager:string="";
strpriority:string=""
 aprojectid:string;
 asdate:string;
 aedate:string;
 aprio:string;
 amanager:string;
 a : boolean = false;
 b : boolean = false;
 c : boolean = false;
 d : boolean = false;
 e : boolean = false;
 responsemsg : string;
  marked = false;
  format: string = 'dd/MM/yyyy';
  public  addProject(){
    console.log(this.addProjectForm.value);
   
   
    this.projectid=this.addProjectForm.get('project').value;
    this.sdate=this.addProjectForm.get('sd').value;
    this.edate=this.addProjectForm.get('ed').value;
    this.prio=this.addProjectForm.get('priority').value;
    this.manager=this.addProjectForm.get('user').value;
    this.addProjectForm.get('startdate').setValue(this.sdate);
    this.addProjectForm.get('enddate').setValue(this.edate);
   alert(this.prio)
   if(this.projectid != null && this.projectid.length>0){
     this.a = true;
     this.projectid="";
   }else{
     this.a = false;
     this.projectid = "Please enter valid project."
   }
   if(this.sdate != null && this.sdate.length>0){
     this.b = true;
   }else{
     this.b = false;
     this.sdate = ""
   }
   if(this.edate != null && this.edate.length>0){
     this.c = true;
   }else{
     this.c = false;
     this.edate = "";
   }
   if(this.manager != null && this.manager.length>0){
     this.d = true;
     this.manager = "";
   }else{
     this.d =false;
     this.manager = "Please selete Manager from the list";
   }
   if(this.prio > 0){
    this.e = true;
    this.prio = 0;
    this.strpriority = "";
   }else{
    this.strpriority = "Please set correct priority";
   }

    if(this.a && this.b && this.c && this.d && this.e){
      this.taskService.addProject(this.addProjectForm.value).subscribe(data=>{
        console.log(data);
        this.responsemsg =data.response;
        this.getAllProjects();
      });
    }  
  }
   onBack(): void {
     //this.router.navigate(['/viewTask']);
     this.addProjectForm.get('project').setValue("");
     this.addProjectForm.get('user').setValue("");
     this.addProjectForm.get('priority').setValue(0);
   }
  checkValue(e){
    console.log(e);
    
    this.marked= e.target.checked;
    alert(this.marked)
    if(this.marked){
      this.addProjectForm.get('sd').enable();
      this.addProjectForm.get('ed').enable();
     
    }else{
      this.addProjectForm.get('sd').disable();
      this.addProjectForm.get('ed').disable();
    }

     let date = JSON.stringify(this.myDate)
      let nextday = JSON.stringify(this.nextDayDate)
      date = date.slice(1,11)
      nextday = nextday.slice(1,11)
      this.addProjectForm.get('sd').value(date);
      this.addProjectForm.get('ed').value(nextday);
  }
  getUsers(){
    this.taskService.getAllUsers().subscribe(data=>{
      
      this.users = data.userList;
      console.log("test" + data.userList);
      for (const i in this.users) {
        //alert(this.users[i].userid)
      }
    
    });
  }
  selectUser(){
    //alert(this.addProjectForm.get('manager').value);
    this.addProjectForm.get('user').setValue(this.addProjectForm.get('manager').value);
  }


  getAllProjects() {
    this.taskService.getAllProjects().subscribe(data=>{
      
      this.projects = data.projectList;
      console.log("test" + data.projectList);

      for (const i in this.projects) {
        //alert(this.projects[i].project)
        // if (this.projects[i]) {
         
        //   this.projects[i].tasksCountStr = this.projects[i].tasksCount.toString();
        //   this.projects[i].completedStr = this.projects[i].completed.toString();
        //   this.projects[i].priorityStr = this.projects[i].priority.toString();
        // }
      }
    
    });
  }
  sort(sortField) {
    switch (sortField) {
      case 'sd':
        this.projects.sort((a, b) => {
          if (a.sd < b.sd) {
            return -1;
          } else if (a.sd > b.sd) {
            return 1;
          } else {
            return 0;
          }
        });
        break;
      case 'ed':
        this.projects.sort((a, b) => {
          if (a.ed < b.ed) {
            return -1;
          } else if (a.ed > b.ed) {
            return 1;
          } else {
            return 0;
          }
        });
        break;
      case 'priority':
        this.projects.sort((a, b) => {
          if (a.priority < b.priority) {
            return -1;
          } else if (a.priority > b.priority) {
            return 1;
          } else {
            return 0;
          }
        });
        break;
      case 'completed':
        this.projects.sort((a, b) => {
          if (a.completed < b.completed) {
            return -1;
          } else if (a.completed > b.completed) {
            return 1;
          } else {
            return 0;
          }
        });
        break;
    }
  }
  
}
