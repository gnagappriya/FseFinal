export class TaskManager{
	
parenttask : string;
task : string;
startdate : string;
enddate : string;
priority : number;
error: string;
priorityfrom: string;
priorityto :string;
status:string;
project:string;
user:string;
projectid:number;
userid:string;
}
export class JsonResponse{
	taskmanagerlist : TaskManagerMaster[];
	status : string;
	
}
export class User{
	userList : AddUser[];
	response : string;
	
}
export class Project{
	projectList : AddProject[];
	response : string;
	
}
export class TaskManagerMaster{
	parentid:number;
	taskid : number;
     task : string ;
	 startdate : string ;
	 enddate : string ;
	 priority : string ;
	 parentTask : string ;
	 taskstatus: string ;
	 response: string;
	 project:string;
	 user:string;
	 projectid:string;
	 userid:string;
}

export class AddProject{
	project: string ;
    checkDate: string ;
    startdate: string ;
    priority: string ;
    enddate: string ;
	user: string ;
	response: string;
    manager: string;
    sd: Date;
	ed: Date;
	projectid: number ;
	taskCount: number;
	completedCount: number;
}
export class AddUser{
	 userid: number;
	 firstname: string;
	 lastname: string;
	 employeeid: string; 
	 projectid : number;
	 taskid: number;
	 response: string;
}
export class ParentTask{
	 parentid: number;
	 parenttask: string;
}
export class ParentTaskList{
	parentTaskList: ParentTask[];
	response : string;
}
