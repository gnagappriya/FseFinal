import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import {TaskManager,AddProject,Project,TaskManagerMaster,AddUser,ParentTaskList,ParentTask} from '../TaskManager';
import {TaskServiceService} from '../task-service.service';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})

export class AddTaskComponent implements OnInit {
  responsemsg : string;
  projects: AddProject[]=[];
  tasks:ParentTask[]=[];
  users:AddUser[]=[];
  tmpTask:string;
  tmpProject :string;
  tmpTaskname : string;
  tmppriority : string;
  tmpparenttask : string;
  tmpstartdate : string;
  tmpenddate : string;
  tmpuser : string;
  a : boolean = false;
  b : boolean = false;
  c : boolean = false;
  d : boolean = false;
  e : boolean = false;
  f : boolean = false;
  g : boolean = false;
  taskForm = new FormGroup({
    task: new FormControl(''),
    priority: new FormControl(''),
    parenttask: new FormControl(''),
    parentid: new FormControl(''),
    startdate: new FormControl(''),
    enddate: new FormControl(''),
    project: new FormControl(''),
    user :new FormControl(''),
    selproject: new FormControl(''),
    isparenttask : new FormControl(''),
    seltask:new FormControl(''),
    seluser:new FormControl(''),
    searchProject:new FormControl(''),
    searchbtnTask: new FormControl(''),
    searchUser: new FormControl(''),
    projectid:new FormControl(''),
  });
  dateRangeValue: Date[];
  nextDate = new Date();
  constructor(public route: ActivatedRoute,
    public router: Router,
    public taskService : TaskServiceService,
  ) { 
  
  }

  ngOnInit() {
    console.log(this.taskForm.value);
    console.log("called service");
    this.tmpProject ="";
    this.tmpTaskname ="";
    
    //this.tmppriority ="Please select Priority";
    this.tmpparenttask ="";
    this.tmpstartdate="";
    this.tmpenddate ="";
    this. tmpuser="";
  }

  public  addUpdateTask(){
    this.tmpProject = this.taskForm.get('project').value;
    
        this.tmpTaskname =this.taskForm.get('task').value;
        
        this.tmppriority =this.taskForm.get('priority').value;
        this.tmpparenttask =this.taskForm.get('parenttask').value;
        this.tmpstartdate =this.taskForm.get('startdate').value;
        this.tmpenddate =this.taskForm.get('enddate').value;
        this. tmpuser =this.taskForm.get('user').value;
      
        console.log("this.taskForm.get('projectid').value :"+this.taskForm.get('projectid').value)
    console.log(this.taskForm.value);
    this.tmpTask = this.taskForm.get('task').value;
   //alert(" this.tmpstartdate"+ this.tmpstartdate.length)
   //alert("this.tmpenddate"+this.tmpenddate)
    if(this.taskForm.get('isparenttask').value == true){
      if(this.tmpTask != null && this.tmpTask.length > 0){
        this.taskService.addParentTask(this.taskForm.value).subscribe(data=>{
          console.log(data);
          this.responsemsg = data.status;
        });
      }else{
        alert("Please enter valid task name");
      }
    }else{
    
      if(this.tmpProject != null && this.tmpProject.length >0){
        this.a = true;
        this.tmpProject = "";
      }else{
        this.a = false;
      }
      if(this.tmpTaskname != null && this.tmpTaskname.length >0){
        this.b = true;
      }else{
        this.b = false;
      }
      if(this.tmppriority != null && this.tmppriority.length >0){
        this.c = true;
      }else{
        this.c = false;
      }
      if(this.tmpparenttask != null && this.tmpparenttask.length >0){
        this.d = true;
      }else{
        this.d = false;
      }
      if(this.tmpstartdate != null ){
        this.e = true;
      }else{
        this.e = false;
      }
      if(this.tmpenddate != null ){
        this.f = true;
      }else{
        this.f = false;
      }
      if(this.tmpuser != null ){
        this.g = true;
      }else{
        this.g = false;
      }
      
      if(this.a  &&   this.b  &&  this.d  &&  this.e  &&    this.f  &&   this.g ){
        this.taskService.addTask(this.taskForm.value).subscribe(data=>{
          console.log(data);
          this.responsemsg = data.status;
          this.tmpProject = "";
          
          this.tmpTaskname ="";
          
          //this.tmppriority ="Please select Priority";
          this.tmpparenttask ="";
          this.tmpstartdate ="";
          this.tmpenddate ="";
          this. tmpuser ="";
          this.tmpProject = "";
          this.getTasks();
        });
      }else{
        
        this.a = false;
        this.b =false;
        this.c =false;
        this.d =false;
        this.e =false;
        this.f =false;
        this.g =false;
        this.tmpProject = "Please select Project";
        
        this.tmpTaskname ="Please select correct Task";
        
        //this.tmppriority ="Please select Priority";
        this.tmpparenttask ="Please select Parent Task";
        this.tmpstartdate ="Please enter Start Date";
        this.tmpenddate ="Please enter end Date";
        this. tmpuser ="Please select correct User";

      }
    }
   
  }

  

checkParentTask(event) {
  if (event.target.checked) {
    this.taskForm.get('priority').disable();
    this.taskForm.get('parenttask').disable();
    this.taskForm.get('startdate').disable();
    this.taskForm.get('enddate').disable();
    this.taskForm.get('user').disable();
    this.taskForm.get('searchProject').disable();
    this.taskForm.get('project').disable();
    this.taskForm.get('searchbtnTask').disable();
     this.taskForm.get('searchUser').disable();
    
    // if(this.taskForm.get('isparenttask').value == true){
    //   if(this.tmpTask != null && this.tmpTask.length > 0){
    //     this.taskService.addParentTask(this.taskForm.value).subscribe(data=>{
    //       console.log(data);
    //       this.responsemsg = data.status;
    //     });
    //   }else{
    //     alert("Please enter valid task name");
    //   }
    // }
    // this.getTasks();
  } else {
    this.taskForm.get('priority').enable();
    this.taskForm.get('parenttask').enable();
    this.taskForm.get('startdate').enable();
    this.taskForm.get('enddate').enable();
    this.taskForm.get('user').enable();
    this.taskForm.get('project').enable();
  }
}


  onBack(): void {
    this.router.navigate(['/viewTask']);
  }
  getProjects(){
    this.taskService.getAllProjects().subscribe(data=>{
      
      this.projects = data.projectList;
      console.log("test" + data.projectList);
      for (const i in this.projects) {
        
      }
    
    });
  }

  levelNum:number;
  levels:Array<Object> = [
    {num: 0, name: "AA"},
    {num: 1, name: "BB"}
];
  toNumber(){
    this.levelNum = +this.levelNum;
    console.log(this.levelNum);
  }
  addProj: AddProject;
  selectProject(){
    this.addProj = this.taskForm.get('selproject').value;
    this.taskForm.get('project').setValue(this.addProj.project);
    this.taskForm.get('projectid').setValue(this.addProj.projectid);
    this.tmpProject ="";
  }
  getTasks(){
    
    this.taskService.getAllParentTasks().subscribe(data=>{
      
      this.tasks = data.parentTaskList;
      
      console.log("Task List :" + data.parentTaskList);
      for(const i in  this.tasks){
        //alert( this.tasks[i].parenttask)
      }
    
    });
  }
  parenttasks : ParentTask;
  selectTask(){

    this.parenttasks = this.taskForm.get('seltask').value;
    
    this.taskForm.get('parentid').setValue(this.parenttasks.parentid);
    this.taskForm.get('parenttask').setValue(this.parenttasks.parenttask);
  }

  getAllUsers(){
    this.taskService.getAllUsers().subscribe(data=>{
      
      this.users = data.userList;
      console.log("users" + data.userList);
      for (const i in this.users) {
        //alert(this.users[i].userid)
      }
    
    });
  }
selectUser(){
  this.taskForm.get('user').setValue(this.taskForm.get('seluser').value);
}
}
