import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

import { HttpClient } from '@angular/common/http';
import {TaskManager,User, AddUser} from '../TaskManager';
import {TaskServiceService} from '../task-service.service';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  pageTitle="Add New User";
  responsemsg : string;
  fname: string="";
  lname:string="";
  empid:string="";
  uid: string="";
  afname: string;
  alname:string;
  aempid:string;
  
  a : boolean = false;
  b : boolean = false;
  c : boolean = false;
  users : AddUser[]=[] ;
  addEditButton : string = 'Add';
  constructor(public route: ActivatedRoute,
    public router: Router,
    public taskService : TaskServiceService,) {
      
     }

  ngOnInit() {
    this.responsemsg ="";
    this.getAllUsers();
    this.addEditButton = "Add";
  }
  addUserForm = new FormGroup({
    firstname: new FormControl(''),
    lastname: new FormControl(''),
    employeeid: new FormControl(''),
    userid: new FormControl(''),
  });
  public addUser(){
    console.log(this.addUserForm.value);

    this.fname=this.addUserForm.get('firstname').value;
    this.lname=this.addUserForm.get('lastname').value;
    this.empid=this.addUserForm.get('employeeid').value;
    this.uid=this.addUserForm.get('userid').value;
  //alert ("User id is:"+this.uid)
   if(this.fname.length>0){
    this.afname=this.fname;
     this.fname='';
     this.a = true;
     this.responsemsg ="";
   }else{
    this.responsemsg ='';
    this.fname="First Name should not be empty";
    
   }
   if(this.lname.length>0){
    this.alname=this.lname;
    this.lname='';
    this.b = true;
    this.responsemsg ="";
  }else{
    this.responsemsg ='';
   this.lname="Last Name should not be empty";
   
  }
  if(this.empid.length>0){
    this.aempid=this.empid;
    this.empid='';
    this.c = true;
    this.responsemsg ="";
  }else{
    this.responsemsg ='';
   this.empid="Employee Id should not be empty";
   
  }

  
    if(this.a && this.b && this.c){
      if(this.addEditButton == "Add"){
        alert(this.addEditButton)
        this.taskService.addUser(this.addUserForm.value).subscribe(data=>{
          console.log(data);
          this.a = false;
          this.b = false;
          this.c = false;
          this.responsemsg =data.response;
          this.getAllUsers();
        });
        
      }else{
        alert(this.addEditButton )
        this.taskService.updateUser(this.addUserForm.value).subscribe(data=>{
          console.log(data);
          this.a = false;
          this.b = false;
          this.c = false;
          this.responsemsg =data.response;
          this.getAllUsers();
        });
        
      }
     
    }
   
  }

  reset() {
    this.responsemsg ='';
    this.addUserForm.get('firstname').setValue('');
    this.addUserForm.get('lastname').setValue('');
    this.addUserForm.get('employeeid').setValue('');
    this.addUserForm.get('employeeid').enable();
  }

  getAllUsers(){
    this.taskService.getAllUsers().subscribe(data=>{
      
      this.users = data.userList;
      console.log("test" + data.userList);
      for (const i in this.users) {
        //alert(this.users[i].userid)
      }
    
    });
  }

  editUSer(u:AddUser){
    this.addUserForm.get('firstname').setValue(u.firstname);
    this.addUserForm.get('lastname').setValue(u.lastname);
    this.addUserForm.get('employeeid').setValue(u.employeeid);
    this.addUserForm.get('userid').setValue(u.userid);
    this.addEditButton = "Update";
  }

  delteUser(u:AddUser){
    alert(u.userid)
    this.taskService.deleteUser(u).subscribe(data=>{
     // this.users = data.userList;
      console.log("test" + data.userList);
      });
      this.getAllUsers();
  }
  sort(sortField) {
    switch (sortField) {
      case 'firstname':
        this.users.sort((a, b) => {
          if (a.firstname.toLowerCase() < b.firstname.toLowerCase()) {
            return -1;
          } else if (a.firstname.toLowerCase() > b.firstname.toLowerCase()) {
            return 1;
          } else {
            return 0;
          }
        });
        break;
      case 'lastName':
        this.users.sort((a, b) => {
          if (a.lastname.toLowerCase() < b.lastname.toLowerCase()) {
            return -1;
          } else if (a.lastname.toLowerCase() > b.lastname.toLowerCase()) {
            return 1;
          } else {
            return 0;
          }
        });
        break;
      case 'employeeId':
        this.users.sort((a, b) => {
          if (a.employeeid < b.employeeid) {
            return -1;
          } else if (a.employeeid > b.employeeid) {
            return 1;
          } else {
            return 0;
          }
        });
        break;
    }
  }
 
}
