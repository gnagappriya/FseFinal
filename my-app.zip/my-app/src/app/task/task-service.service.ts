import {HttpClient } from '@angular/common/http';
import {Injectable} from '@angular/core';
import {TaskManager,TaskManagerMaster,JsonResponse,AddProject,User, AddUser,Project,ParentTaskList} from '../task/TaskManager';

@Injectable({
  providedIn: 'root'
})
export class TaskServiceService {

  constructor(public http: HttpClient) { }
users : User[];

addParentTask(tm:TaskManager){
  console.log("Calling service - http://localhost:8082/taskManager/addParentTask")
  
  return this.http.post<TaskManager>('http://localhost:8082/taskManager/addParentTask',tm);
}
  addTask(tm:TaskManager ){
    console.log("Calling service - http://localhost:8082/taskManager/addTask")
    
    return this.http.post<TaskManager>('http://localhost:8082/taskManager/addTask',tm);
  }

  getTaskManagerMaster(){
    console.log ("calling service - http://localhost:8082/taskManager/getAllTasks");
    return this.http.get<JsonResponse>('http://localhost:8082/taskManager/getAllTasks');
  }


  endTask(t:TaskManagerMaster){
    console.log ("calling service - http://localhost:8082/taskManager/suspendTask");
    let url ="http://localhost:8082/taskManager/suspendTask/";
    
    console.log (t)
    let response  = this.http.post<JsonResponse>(url, t);
    return response;
  }
  updateTask(t:TaskManagerMaster){
    console.log ("calling service - http://localhost:8082/taskManager/updateTask");
    let url ="http://localhost:8082/taskManager/updateTask/";
    
    console.log (t)
    let response  = this.http.post<TaskManagerMaster>(url, t);
    return response;
  }

  addProject(t:AddProject){
    console.log ("calling service - http://localhost:8082/taskManager/addProject");
    let url ="http://localhost:8082/taskManager/addProject/";
    
    console.log (t)
    let response  = this.http.post<AddProject>(url, t);
    return response;
  }

  addUser(t:AddUser){
    
    console.log ("calling service - http://localhost:8082/taskManager/addUser");
    let url ="http://localhost:8082/taskManager/addUser/";
    
    console.log (t)
    let response  = this.http.post<AddUser>(url, t);
    return response;
  }

  getAllUsers(){
    console.log ("calling service - http://localhost:8082/taskManager/getAllUsers");

    return this.http.get<User>('http://localhost:8082/taskManager/getAllUsers');
  }
  deleteUser(u:AddUser){
    console.log ("calling service - http://localhost:8082/taskManager/deleteUser");
    return this.http.post<User>('http://localhost:8082/taskManager/deleteUser',u);
  }
  updateUser(u:AddUser){
    console.log ("calling service - http://localhost:8082/taskManager/updateUser");
    return this.http.post<User>('http://localhost:8082/taskManager/updateUser',u);
  }
  getAllProjects(){
    console.log ("calling service - http://localhost:8082/taskManager/getAllProjects");
    
        return this.http.get<Project>('http://localhost:8082/taskManager/getAllProjects');
  }

  getAllParentTasks(){
    
    console.log ("calling service - http://localhost:8082/taskManager/getAllParentTasks");
    
        return this.http.get<ParentTaskList>('http://localhost:8082/taskManager/getAllParentTasks');
  }
}
