import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {EditTaskComponent} from '../app/task/edit-task/edit-task.component';


const routes: Routes = [

  {
    path: 'editTask',
    component: EditTaskComponent
    
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 



}
