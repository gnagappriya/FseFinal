import { BrowserModule } from '@angular/platform-browser';
import { NgModule,ViewChild, AfterViewInit, ElementRef,OnDestroy } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeListComponent } from 'src/app/employee/employee-list.component';
import { EmpDetailComponent } from './employee/emp-detail/emp-detail.component';
import { WelcomeComponentComponent } from './welcome-component/welcome-component.component';
import { AddTaskComponent } from './task/add-task/add-task.component';
import { ViewTaskComponent } from './task/view-task/view-task.component';
import { EditTaskComponent } from './task/edit-task/edit-task.component';
import { EndTaskComponent } from './task/end-task/end-task.component';
import {TaskServiceService} from './task/task-service.service';
import {TaskManager} from './task/TaskManager';
import { TestCompComponent } from './test/test-comp/test-comp.component';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule} from 'ngx-bootstrap';
import { AddProjectComponent } from './task/add-project/add-project.component';
import { AddUserComponent } from './task/add-user/add-user.component';
import { FormGroup, FormControl, NgControl } from '@angular/forms';
import { Directive } from '@angular/core';


@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    EmployeeComponent,
    EmployeeListComponent,
    EmpDetailComponent,
    WelcomeComponentComponent,
    AddTaskComponent,
    ViewTaskComponent,
    EditTaskComponent,
    EndTaskComponent,
    TestCompComponent,
    AddProjectComponent,
    AddUserComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,ReactiveFormsModule,
    FormsModule,
    BsDatepickerModule.forRoot(),
    RouterModule.forRoot([
      {path: 'addProject', component:AddProjectComponent},
      {path: 'addTask', component:AddTaskComponent},
      {path: 'addUser', component:AddUserComponent},
      {path: 'viewTask', component:ViewTaskComponent},
      {path: 'editTask', component:EditTaskComponent},
      {path: 'endTask', component:EndTaskComponent},
      {path: 'employee', component:EmployeeListComponent},
      {path: 'employee/:id', component:EmpDetailComponent},
      {path: 'welcome', component:WelcomeComponentComponent},
      {path: 'addEmployee', component:EmployeeComponent},
      {path: 'test', component:TestCompComponent},
      {path: '',redirectTo:'welcome',pathMatch:'full'},
      {path: '**',redirectTo:'welcome',pathMatch:'full'}
        
    ], { useHash:true}),
    
    BrowserAnimationsModule
  ],
  exports:[
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
