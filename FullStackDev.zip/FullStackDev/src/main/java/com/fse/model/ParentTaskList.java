package com.fse.model;

import java.util.List;

public class ParentTaskList {
	List<ParentTask> parentTaskList;

	public List<ParentTask> getParentTaskList() {
		return parentTaskList;
	}

	public void setParentTaskList(List<ParentTask> parentTaskList) {
		this.parentTaskList = parentTaskList;
	}
		
}
