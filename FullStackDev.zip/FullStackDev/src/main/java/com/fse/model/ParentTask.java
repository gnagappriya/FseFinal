package com.fse.model;

public class ParentTask {
	int parentid;
	String parenttask;
	public int getParentid() {
		return parentid;
	}
	public void setParentid(int parentid) {
		this.parentid = parentid;
	}
	public String getParenttask() {
		return parenttask;
	}
	public void setParenttask(String parenttask) {
		this.parenttask = parenttask;
	}
	
	
}
