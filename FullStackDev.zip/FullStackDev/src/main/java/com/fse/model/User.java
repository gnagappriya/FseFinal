package com.fse.model;

import java.util.List;

public class User {
	List<AddUser> userList;
	
	public List<AddUser> getUserList() {
		return userList;
	}

	public void setUserList(List<AddUser> userList) {
		this.userList = userList;
	}

	
	
	
}
