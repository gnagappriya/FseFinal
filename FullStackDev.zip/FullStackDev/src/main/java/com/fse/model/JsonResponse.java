package com.fse.model;

import java.util.List;

public class JsonResponse {

	List<TaskManagerMaster> taskmanagerlist;
	
	String status;
	public List<TaskManagerMaster> getTaskmanagerlist() {
		return taskmanagerlist;
	}
	public void setTaskmanagerlist(List<TaskManagerMaster> taskmanagerlist) {
		this.taskmanagerlist = taskmanagerlist;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
