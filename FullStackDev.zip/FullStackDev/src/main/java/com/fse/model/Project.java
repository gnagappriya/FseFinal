package com.fse.model;

import java.util.List;

public class Project {
	List<AddProject> projectList;
	String response;
	public List<AddProject> getProjectList() {
		return projectList;
	}
	public void setProjectList(List<AddProject> projectList) {
		this.projectList = projectList;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	
}
