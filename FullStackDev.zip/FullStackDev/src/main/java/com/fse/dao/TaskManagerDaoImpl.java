package com.fse.dao;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fse.entity.ParentTaskTable;
import com.fse.entity.ProjectTable;
import com.fse.entity.TaskTable;
import com.fse.entity.UsersTable;
import com.fse.model.AddProject;
import com.fse.model.AddUser;
import com.fse.model.ParentTask;
import com.fse.model.TaskManagerMaster;

@Repository
@Transactional
public class TaskManagerDaoImpl implements TaskManagerDao{

	 @Autowired
	 private SessionFactory sessionFactory;
	@Override
	public String addTask(ParentTaskTable ptt) {
		
		
		sessionFactory.getCurrentSession().saveOrUpdate(ptt);
		return ptt.getParenttask() + "added successfully into Database.";
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<TaskManagerMaster> getAllTasks() {
		
		List<ParentTaskTable> pt =sessionFactory.getCurrentSession().createNamedQuery("ParentTaskTable.getAllTasks", ParentTaskTable.class).list();
		List<TaskManagerMaster> taskManagerMasterList = new ArrayList<>();
		for(ParentTaskTable ptt : pt) {
			
			TaskManagerMaster taskManagerMaster = new TaskManagerMaster();
			taskManagerMaster.setParentid(ptt.getParentid());
			taskManagerMaster.setParentTask(ptt.getParenttask());
			for(TaskTable tt: ptt.getTaskTableList()) {
				taskManagerMaster.setTaskid(tt.getTaskid());
				taskManagerMaster.setTask(tt.getTask());
				taskManagerMaster.setPriority(tt.getPriority());
				
				taskManagerMaster.setStartdate(String.valueOf(tt.getStartdate()));
				taskManagerMaster.setEnddate(String.valueOf(tt.getEnddate()));
				taskManagerMaster.setTaskstatus(tt.getTaskstatus());
				taskManagerMasterList.add(taskManagerMaster);
			}
		}
		return (List<TaskManagerMaster>) taskManagerMasterList;
	}
	
	
	
	public Date getStringFromDate(String d) throws ParseException {
		/*DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		String strDate = dateFormat.format(date);
		
		return strDate;*/
		String DATE_FORMAT_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

		  DateFormat formatter=new SimpleDateFormat(DATE_FORMAT_PATTERN);  
		  Date date=(Date) formatter.parse(d);
		  SimpleDateFormat sd = new SimpleDateFormat("MM/dd/yyyy");
		  SimpleDateFormat sd1 = new SimpleDateFormat("MM/dd/yyyy");
		  java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		 
		  return sqlDate;
	}
	@Override
	public List<TaskManagerMaster> suspendTask(TaskManagerMaster taskManagerMaster) {
		Query query =  sessionFactory.getCurrentSession().createQuery(" update TaskTable set taskstatus = :taskstatus where taskid = :taskid ");
		 query.setParameter("taskstatus", taskManagerMaster.getTaskstatus());
		 query.setParameter("taskid", taskManagerMaster.getTaskid());
		 int result = query.executeUpdate();
		
		
		 
		 
		return getAllTasks();
	}
	@Override
	public int updateTask(TaskManagerMaster taskManagerMaster) throws ParseException {
		
		//List<TaskTable> tt=   sessionFactory.getCurrentSession().createQuery("TaskTable.getTaskByID",TaskTable.class).setParameter("pid", pid).setParameter("tid", tid).list();
		Query query=   sessionFactory.getCurrentSession().createQuery("update TaskTable set task= :task, startdate=:startdate, enddate=:enddate, priority=:priority where parentid =:parentid and taskid =:taskid");
		query.setParameter("task", taskManagerMaster.getTask());
		 query.setParameter("startdate", getDate(taskManagerMaster.getStartdate()));
		 query.setParameter("enddate", getDate(taskManagerMaster.getEnddate()));
		 query.setParameter("priority", taskManagerMaster.getPriority());
		 query.setParameter("parentid", taskManagerMaster.getParentid());
		 query.setParameter("taskid", taskManagerMaster.getTaskid());
		 int result = query.executeUpdate();
		 return result;
	}
	/*public Date getDate (String d) throws ParseException{
		String DATE_FORMAT_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

		  SimpleDateFormat formatter=new SimpleDateFormat(DATE_FORMAT_PATTERN);
		  java.util.Date utilDate = formatter.parse(d);
		 
		  return utilDate;
	}*/
	public Date getDate (String d) throws ParseException{
		String DATE_FORMAT_PATTERN = "yyyy-MM-dd";

		  DateFormat formatter=new SimpleDateFormat(DATE_FORMAT_PATTERN);  
		  Date date=(Date) formatter.parse(d);
		  Date dd = new Date(date.getTime());
		  //java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		 
		  return dd;
	}
	@Override
	public String addProject(ProjectTable projectTable) {
		
		sessionFactory.getCurrentSession().saveOrUpdate(projectTable);
		return projectTable.getProject();
	}
	@Override
	public String addUser(UsersTable usersTable) {
		Query query = sessionFactory.getCurrentSession().createSQLQuery("select * from UsersTable where employeeid=:e");
		query.setParameter("e", usersTable.getEmployeeid());
		List<UsersTable> usersList = query.getResultList();
		String response = null;
		if(usersList.size()>1) {
			response = "User "+usersTable.getEmployeeid()+" already exists in Database.";
		}else {
			sessionFactory.getCurrentSession().saveOrUpdate(usersTable);
			response = " User "+usersTable.getEmployeeid()+" saved in to Database.";
		}
		
		return response;
	}
	@Override
	public List<AddUser> getAllUsers() {
		List<UsersTable> userList =sessionFactory.getCurrentSession().createNamedQuery("UsersTable.getAllUsers", UsersTable.class).list();
		List<AddUser> users = new ArrayList<>();
		for(UsersTable ut:userList) {
			AddUser usr = new AddUser();
			usr.setFirstname(ut.getFirstname());
			usr.setLastname(ut.getLastname());
			usr.setEmployeeid(ut.getEmployeeid());
			usr.setUserid(ut.getUserid());
			users.add(usr);
		}
		return users;
	}
	@Override
	public String updateUser(AddUser addUser) throws ParseException {
		
		Query query=   sessionFactory.getCurrentSession().createQuery("update UsersTable set firstname= :fn, lastname=:ln , employeeid =:eid where userid= :uid");
		query.setParameter("fn", addUser.getFirstname());
		query.setParameter("ln", addUser.getLastname());
		query.setParameter("eid", addUser.getEmployeeid());
		query.setParameter("uid", addUser.getUserid());
		 int result = query.executeUpdate();
		 String response = null;
		 if(result>0) {
			 response = " User "+addUser.getUserid()+" saved in to Database successfully."; 
		 }
		
		return response;
	}
	@Override
	public String deleteUser(AddUser addUser) throws ParseException {
		Query query=   sessionFactory.getCurrentSession().createQuery("delete from UsersTable where userid= :uid");
		query.setParameter("uid", addUser.getUserid());
		 int result = query.executeUpdate();
		 String response = null;
		 if(result>0) {
			 response = " User "+addUser.getUserid()+" deleted from Database successfully."; 
		 }
		
		return response;
	}
	@Override
	public List<AddProject> getAllProjects() {
		List<ProjectTable> projectList =sessionFactory.getCurrentSession().createNamedQuery("ProjectTable.getAllProjects", ProjectTable.class).list();
		List<AddProject> projList = new ArrayList<>();
		for(ProjectTable pt:projectList) {
			AddProject p = new AddProject();
			p.setProjectid(pt.getProjectid());
			p.setProject(pt.getProject());
			p.setSd(pt.getStartdate());
			p.setEd(pt.getEnddate());
			p.setTaskCount(pt.getTaskTableList().size());
			projList.add(p);
		}
		return projList;
	}
	@Override
	public String deleteProject(AddProject addProject) throws ParseException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<ParentTask> getAllParentTasks() {
		List<ParentTaskTable> pttList =sessionFactory.getCurrentSession().createNamedQuery("ParentTaskTable.getAllTasks", ParentTaskTable.class).list();
		List<ParentTask> ptList = new ArrayList<>();
		for(ParentTaskTable pt:pttList) {
			ParentTask p = new ParentTask();
			p.setParentid(pt.getParentid());
			p.setParenttask(pt.getParenttask());
			ptList.add(p);
		}
		return ptList;
	}
	@Override
	public List<ProjectTable> getProjectById(int projid) {
		Query query = sessionFactory.getCurrentSession().createSQLQuery("select * from ProjectTable where projectid=:p");
		query.setParameter("p", projid);
		List<ProjectTable> projectList = (List<ProjectTable>)query.getResultList();
		//ProjectTable pt = new ProjectTable();
//		if(projectList.size()>0) {
//			pt =projectList.get(0);
//		}
		return projectList;
	}
	@Override
	public List<ParentTaskTable> checkParentTaskExists(String task) {
		Query query = sessionFactory.getCurrentSession().createSQLQuery("select * from ParentTaskTable where parenttask=:pt");
		query.setParameter("pt", task);
		List<ParentTaskTable> taskList = query.getResultList();
		
		return taskList;
	}
	@Override
	public List<ProjectTable> getProjectByName(String project) {
		Query query = sessionFactory.getCurrentSession().createSQLQuery("select * from ProjectTable where project=:p");
		query.setParameter("p", project);
		List<ProjectTable> projectList = query.getResultList();
		
		return projectList;
	}
	@Override
	public List<ProjectTable> getAllProjectList() {
		//List<ProjectTable> projectList =sessionFactory.getCurrentSession().createNamedQuery("ProjectTable.getAllProjects", ProjectTable.class).list();
		
		return sessionFactory.getCurrentSession().createNamedQuery("ProjectTable.getAllProjects", ProjectTable.class).list();
	}
	@Override
	public List<ParentTaskTable> getAllParentTasksList() {
		
		return sessionFactory.getCurrentSession().createNamedQuery("ParentTaskTable.getAllTasks", ParentTaskTable.class).list();
	}
	@Override
	public String addTaskTable(TaskTable tt) {
		sessionFactory.getCurrentSession().saveOrUpdate(tt);
		return tt.getTask() + "added successfully into Database.";
		
	}
	
}
