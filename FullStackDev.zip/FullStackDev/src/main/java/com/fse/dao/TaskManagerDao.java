package com.fse.dao;

import java.text.ParseException;
import java.util.List;

import com.fse.entity.ParentTaskTable;
import com.fse.entity.ProjectTable;
import com.fse.entity.TaskTable;
import com.fse.entity.UsersTable;
import com.fse.model.AddProject;
import com.fse.model.AddUser;
import com.fse.model.ParentTask;
import com.fse.model.TaskManagerMaster;

public interface TaskManagerDao {
	public String addTask(ParentTaskTable ptt);
	public List<TaskManagerMaster> getAllTasks();
	public List<TaskManagerMaster> suspendTask(TaskManagerMaster taskManagerMaster);
	public int updateTask(TaskManagerMaster taskManagerMaster) throws ParseException;
	public String addProject(ProjectTable projectTable);
	public String addUser(UsersTable usersTable);
	public List<AddUser> getAllUsers();
	public String updateUser(AddUser addUser) throws ParseException;
	public String deleteUser(AddUser addUser) throws ParseException;
	public List<AddProject> getAllProjects();
	public String deleteProject(AddProject addProject) throws ParseException;
	public List<ParentTask> getAllParentTasks();
	public List<ProjectTable> getProjectById(int projid);
	public List<ParentTaskTable> checkParentTaskExists(String task);
	public List<ProjectTable> getProjectByName(String project);
	public List<ProjectTable> getAllProjectList();
	public List<ParentTaskTable> getAllParentTasksList();
	public String addTaskTable(TaskTable tt);
}
