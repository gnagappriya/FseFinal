package com.fse.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Test {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		String utcDateStr = "2019-08-18T07:29:38.000Z";
		System.out.println("Given date is " + utcDateStr);
		DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		Date d = sdf.parse(utcDateStr);
		System.out.println(d);

		String d1 = utcDateStr;
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"); // your template here
		 Date date=(Date) formatter.parse(d1); 
		 System.out.println(new Date(date.getMonth(), date.getDay(), date.getYear()));
		 
		 java.util.Date utilDate = new java.util.Date();
		    java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		    System.out.println("utilDate:" + utilDate);
		    System.out.println("sqlDate:" + sqlDate);
		    SimpleDateFormat sd = new SimpleDateFormat("MM/dd/yyyy");
		   
		    System.out.println("sqlDate:" +  sd.format(date));

	}

}
