package com.fse.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.fse.entity.ParentTaskTable;
import com.fse.entity.ProjectTable;
import com.fse.entity.TaskTable;
import com.fse.entity.UsersTable;
import com.fse.model.AddProject;
import com.fse.model.AddUser;
import com.fse.model.JsonResponse;
import com.fse.model.ParentTask;
import com.fse.model.ParentTaskList;
import com.fse.model.Project;
import com.fse.model.TaskManager;
import com.fse.model.TaskManagerMaster;
import com.fse.model.User;
import com.fse.service.TaskManagerService;



@RestController
@RequestMapping("taskManager")
@CrossOrigin(origins="*", allowedHeaders="*")
public class TaskManagerController {
	@Autowired
	TaskManagerService taskManagerService;
	
	@PostMapping("suspendTask")
	public ResponseEntity<List<TaskManagerMaster>> suspendTask(@RequestBody TaskManagerMaster taskManager){
		
		taskManager.setTaskstatus("COMPLETED");
		List<TaskManagerMaster> response = taskManagerService.suspendTask(taskManager);
		return new ResponseEntity<List<TaskManagerMaster>>(response, HttpStatus.CREATED);
	}
	
	
	 
	@PostMapping("addParentTask")
	public ResponseEntity<TaskManager> addParentTask(@RequestBody TaskManager taskManager, UriComponentsBuilder builder) throws ParseException {
		
		List<ParentTaskTable> pttable = taskManagerService.checkParentTaskExists(taskManager.getTask());
		if(CollectionUtils.isEmpty(pttable)) {
			ParentTaskTable ptt = new ParentTaskTable();
			ptt.setParenttask(taskManager.getTask());
			String response = taskManagerService.addTask(ptt);
			taskManager.setStatus("Parent Task saved to Database");
		}else {
			taskManager.setStatus("Parent Task already exists in Database (Parent Task Table), Please give different task name for Parent Task");
		}
		
		//if(taskManager.getParenttask().equals(response)) {
		return new ResponseEntity<TaskManager>(taskManager, HttpStatus.CREATED);
		//}
		//return new ResponseEntity<TaskManager>(taskManager, HttpStatus.EXPECTATION_FAILED);
	}
	
	@PostMapping("addTask")
	public ResponseEntity<TaskManager> addTask(@RequestBody TaskManager taskManager, UriComponentsBuilder builder) throws ParseException {
		
		TaskTable tt = new TaskTable();
		tt.setTask(taskManager.getTask());
		tt.setStartdate(getDate(taskManager.getStartdate()));
		tt.setEnddate(getDate(taskManager.getEnddate()));
		tt.setPriority(taskManager.getPriority());
		List<ProjectTable> projList =taskManagerService.getAllProjectList(); //taskManagerService.getProjectById(taskManager.getProjectid());
		for(ProjectTable proj: projList) {
			if(proj.getProjectid()== taskManager.getProjectid()) {
				tt.setProjectTable(proj);
				break;
			}
		}
		List<ParentTaskTable> ptList = taskManagerService.getAllParentTasksList();
		for(ParentTaskTable ptt : ptList) {
			if(ptt.getParentid() == taskManager.getParentid()) {
				tt.setParentTaskTable(ptt);
				break;
			}
		}
		String response = taskManagerService.addTaskTable(tt);
		taskManager.setStatus(response);
		return new ResponseEntity<TaskManager>(taskManager, HttpStatus.CREATED);
	}
	public Date getDate (String d) throws ParseException{
		String DATE_FORMAT_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

		  DateFormat formatter=new SimpleDateFormat(DATE_FORMAT_PATTERN);  
		  Date date=(Date) formatter.parse(d);
		  SimpleDateFormat sd = new SimpleDateFormat("MM/dd/yyyy");
		  SimpleDateFormat sd1 = new SimpleDateFormat("MM/dd/yyyy");
		  Date dd = new Date(date.getTime());
		  //java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		 
		  return dd;
	}
	
	@SuppressWarnings("unchecked")
	@GetMapping("getAllTasks")
	public ResponseEntity<JsonResponse> getAllTasks(){
		List<TaskManagerMaster> allTasks = taskManagerService.getAllTasks();
		System.out.println("allTasks.size() ==================>"+allTasks.size());
		JsonResponse jsonResponse = new JsonResponse();
		jsonResponse.setTaskmanagerlist(allTasks);
		return  new ResponseEntity<JsonResponse>(jsonResponse,HttpStatus.CREATED);
	}
	@PostMapping("updateTask")
	public ResponseEntity<TaskManagerMaster> getTaskById(@RequestBody TaskManagerMaster taskManager) throws ParseException{
		TaskManagerMaster taskManagerMaster = taskManager;
		taskManagerMaster.setTaskstatus("Data saved to Database successfully..");
		taskManagerService.updateTask(taskManagerMaster);
		
		return  new ResponseEntity<TaskManagerMaster>(taskManagerMaster,HttpStatus.CREATED);
	}
	@PostMapping("addProject")
	public ResponseEntity<AddProject> addProject(@RequestBody AddProject addProject) throws ParseException{
		
		List<ProjectTable> pt = taskManagerService.getProjectByName(addProject.getProject());
		if(CollectionUtils.isEmpty(pt)) {
			DateFormat formatter1 = new SimpleDateFormat("yyyy-mm-dd");
			ProjectTable projectTable = new ProjectTable();
			projectTable.setProject(addProject.getProject());
			projectTable.setPriority(addProject.getPriority());
			projectTable.setStartdate(formatter1.parse(addProject.getStartdate()));
			projectTable.setEnddate(formatter1.parse(addProject.getEnddate()));
			
			taskManagerService.addProject(projectTable);
			addProject.setResponse(addProject.getProject() +" addted in to the Database successfully.");
		}else {
			addProject.setResponse("The Project "+addProject.getProject() +" already exist in the Database, please enter correct project name.");
		}
		
		
		return  new ResponseEntity<AddProject>(addProject,HttpStatus.CREATED);
	}
	@PostMapping("addUser")
	public ResponseEntity<AddUser> addUser(@RequestBody AddUser addUser) throws ParseException{
		UsersTable usersTable = new UsersTable();
		usersTable.setFirstname(addUser.getFirstname());
		usersTable.setLastname(addUser.getLastname());
		usersTable.setEmployeeid(addUser.getEmployeeid());
		usersTable.setTaskid(0);
		usersTable.setProjectid(0);
		String response = taskManagerService.addUser(usersTable);
		addUser.setResponse(response);
		return  new ResponseEntity<AddUser>(addUser,HttpStatus.CREATED);
	}
	@GetMapping("getAllUsers")
	public ResponseEntity<User> getAllUsers(){
		
		User users = new User();
		List<AddUser> userList = taskManagerService.getAllUsers();
		System.out.println("Users ==>"+userList.size());
		users.setUserList(userList);
		return  new ResponseEntity<User>(users,HttpStatus.CREATED);
	}
	@PostMapping("updateUser")
	public ResponseEntity<AddUser> updateUser(@RequestBody AddUser addUser) throws ParseException{
		String response = taskManagerService.updateUser(addUser);
		addUser.setResponse(response);
		return  new ResponseEntity<AddUser>(addUser,HttpStatus.CREATED);
	}
	@PostMapping("deleteUser")
	public ResponseEntity<AddUser> deleteUser(@RequestBody AddUser addUser) throws ParseException{
		String response = taskManagerService.deleteUser(addUser);
		addUser.setResponse(response);
		return  new ResponseEntity<AddUser>(addUser,HttpStatus.CREATED);
	}
	@GetMapping("getAllProjects")
	public ResponseEntity<Project> getAllProjects(){
		
		Project project = new Project();
		List<AddProject> projectList = taskManagerService.getAllProjects();
		
		System.out.println("Project ==>"+projectList.size());
		project.setProjectList(projectList);
		return  new ResponseEntity<Project>(project,HttpStatus.CREATED);
	}
	@GetMapping("getAllParentTasks")
	public ResponseEntity<ParentTaskList> getAllParentTasks(){
		
		ParentTaskList ptt = new ParentTaskList();
		List<ParentTask> parentTaskList = taskManagerService.getAllParentTasks();
		System.out.println("parentTaskList ==>"+parentTaskList.size());
		ptt.setParentTaskList(parentTaskList);
		return  new ResponseEntity<ParentTaskList>(ptt,HttpStatus.CREATED);
	}
}
