package com.fse.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="TaskTable")
//@NamedQuery(name="TaskTable.getTaskByID", query=" from tasktable where parentid = :pid and taskid = :tid ")
public class TaskTable {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int taskid;
	
	
	
	@Column(name="task")
	String task;
	
	
	@Column(name="startdate")
	@Temporal(TemporalType.DATE)
	java.util.Date startdate;
	
	@Column(name="enddate")
	@Temporal(TemporalType.DATE)
	java.util.Date enddate;
	
	
	@Column(name="priority")
	String priority;
	
	@ManyToOne(cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	@JoinColumn(name="parentid")
	ParentTaskTable parentTaskTable;
	
	@Column(name="taskstatus")
	String taskstatus;
	
	@ManyToOne(cascade=CascadeType.MERGE, fetch=FetchType.EAGER)
	@JoinColumn(name="projectid")
	ProjectTable projectTable;
	
	public TaskTable() {
		
	}
	

	public int getTaskid() {
		return taskid;
	}

	public void setTaskid(int taskid) {
		this.taskid = taskid;
	}

	

	public String getTask() {
		return task;
	}

	public void setTask(String task) {
		this.task = task;
	}

	

	


	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public ParentTaskTable getParentTaskTable() {
		return parentTaskTable;
	}

	public void setParentTaskTable(ParentTaskTable parentTaskTable) {
		this.parentTaskTable = parentTaskTable;
	}


	public String getTaskstatus() {
		return taskstatus;
	}


	public void setTaskstatus(String taskstatus) {
		this.taskstatus = taskstatus;
	}


	public Date getStartdate() {
		return startdate;
	}


	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}


	public Date getEnddate() {
		return enddate;
	}


	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}


	public ProjectTable getProjectTable() {
		return projectTable;
	}


	public void setProjectTable(ProjectTable projectTable) {
		this.projectTable = projectTable;
	}


	
	
	
	
}
