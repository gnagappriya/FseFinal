package com.fse.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Table
@Entity(name="ProjectTable")
@NamedQuery(name="ProjectTable.getAllProjects", query=" from ProjectTable")
public class ProjectTable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int projectid ;
	@Column(name="project")
	String project ;
	
	@Column(name="startdate")
	@Temporal(TemporalType.DATE)
	Date startdate;
	
	@Column(name="enddate")
	@Temporal(TemporalType.DATE)
	Date enddate; 
	@Column(name="priority")
	String priority;
	
	@OneToMany(mappedBy="projectTable", cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	List<TaskTable> taskTableList;
	
	
	
	public void addTask(TaskTable taskTable) {
		taskTable.setProjectTable(this);
	}
	public int getProjectid() {
		return projectid;
	}
	public void setProjectid(int projectid) {
		this.projectid = projectid;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public Date getStartdate() {
		return startdate;
	}
	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}
	public Date getEnddate() {
		return enddate;
	}
	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}
	
	public List<TaskTable> getTaskTableList() {
		return taskTableList;
	}
	public void setTaskTableList(List<TaskTable> taskTableList) {
		this.taskTableList = taskTableList;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	
	
}
