package com.fse.service;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fse.dao.TaskManagerDao;
import com.fse.entity.ParentTaskTable;
import com.fse.entity.ProjectTable;
import com.fse.entity.TaskTable;
import com.fse.entity.UsersTable;
import com.fse.model.AddProject;
import com.fse.model.AddUser;
import com.fse.model.ParentTask;
import com.fse.model.TaskManagerMaster;

@Service
public class TaskManagerServiceImpl implements TaskManagerService{

	@Autowired
	TaskManagerDao taskManagerDao;
	@Override
	public String addTask(ParentTaskTable ptt) {
		
		return taskManagerDao.addTask(ptt);
	}
	@Override
	public List<TaskManagerMaster> getAllTasks() {
		return taskManagerDao.getAllTasks();
		
	}
	@Override
	public List<TaskManagerMaster> suspendTask(TaskManagerMaster taskManagerMaster) {
		
		return taskManagerDao.suspendTask(taskManagerMaster);
	}
	@Override
	public int updateTask(TaskManagerMaster taskManagerMaster ) throws ParseException {
		
		return taskManagerDao.updateTask( taskManagerMaster);
	}
	@Override
	public String addProject(ProjectTable projectTable) throws ParseException {
		
		return taskManagerDao.addProject(projectTable);
	}
	@Override
	public String addUser(UsersTable userTable) throws ParseException {
		
		return taskManagerDao.addUser(userTable);
	}
	@Override
	public List<AddUser> getAllUsers() {
		
		return taskManagerDao.getAllUsers();
	}
	@Override
	public String updateUser(AddUser addUser) throws ParseException {
		
		return taskManagerDao.updateUser(addUser);
	}
	@Override
	public String deleteUser(AddUser addUser) throws ParseException {
		// TODO Auto-generated method stub
		return taskManagerDao.deleteUser(addUser);
	}
	@Override
	public List<AddProject> getAllProjects() {
		// TODO Auto-generated method stub
		return taskManagerDao.getAllProjects();
	}
	@Override
	public String deleteProject(AddProject addProject) throws ParseException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<ParentTask> getAllParentTasks() {
		
		return taskManagerDao.getAllParentTasks();
	}
	@Override
	public List<ProjectTable> getProjectById(int projid) {
		// TODO Auto-generated method stub
		return taskManagerDao.getProjectById(projid);
	}
	@Override
	public List<ParentTaskTable> checkParentTaskExists(String task) {
		// TODO Auto-generated method stub
		return taskManagerDao.checkParentTaskExists(task);
	}
	@Override
	public List<ProjectTable> getProjectByName(String project) {
		// TODO Auto-generated method stub
		return taskManagerDao.getProjectByName(project);
	}
	@Override
	public List<ProjectTable> getAllProjectList() {
		// TODO Auto-generated method stub
		return taskManagerDao.getAllProjectList();
	}
	@Override
	public List<ParentTaskTable> getAllParentTasksList() {
		// TODO Auto-generated method stub
		return taskManagerDao.getAllParentTasksList();
	}
	@Override
	public String addTaskTable(TaskTable tt) {
		// TODO Auto-generated method stub
		return taskManagerDao.addTaskTable(tt);
	}

	
}
